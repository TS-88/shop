/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50621
Source Host           : localhost:3306
Source Database       : ci_boot

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2015-03-05 14:10:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT '',
  `description` text,
  `date` date DEFAULT NULL,
  `author` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('2', '1Title 1', 'The jQuery Bower package contains additional files besides the default distribution. In most cases you can ignore these files, however if you wish to download the default release on it\'s own you can use Bower to install jQuery from one of the above urls instead of the registered package. For example, if you wish to install just the compressed jQuery 2.1.0, you can install just that file with the following command:', '2015-02-18', 'Davit Tsaturyan', 'rrr.jpg');
INSERT INTO `news` VALUES ('3', 'Title 2', 'The jQuery Bower package contains additional files besides the default distribution. In most cases you can ignore these files, however if you wish to download the default release on it\'s own you can use Bower to install jQuery from one of the above urls instead of the registered package. For example, if you wish to install just the compressed jQuery 2.1.0, you can install just that file with the following command:', '2024-02-20', 'Gago', 'tt.png');
INSERT INTO `news` VALUES ('5', 'Title 3', 'The jQuery Bower package contains additional files besides the default distribution. In most cases you can ignore these files, however if you wish to download the default release on it\'s own you can use Bower to install jQuery from one of the above urls instead of the registered package. For example, if you wish to install just the compressed jQuery 2.1.0, you can install just that file with the following command:', '2015-02-17', 'Smbo', 'ttgj1.png');
INSERT INTO `news` VALUES ('6', 'Title 4', 'The jQuery Bower package contains additional files besides the default distribution. In most cases you can ignore these files, however if you wish to download the default release on it\'s own you can use Bower to install jQuery from one of the above urls instead of the registered package. For example, if you wish to install just the compressed jQuery 2.1.0, you can install just that file with the following command:', '2015-02-10', 'Harut', 'Penguins.jpg');
INSERT INTO `news` VALUES ('7', 'Volkswagen 5', 'The jQuery Bower package contains additional files besides the default distribution. In most cases you can ignore these files, however if you wish to download the default release on it\'s own you can use Bower to install jQuery from one of the above urls instead of the registered package. For example, if you wish to install just the compressed jQuery 2.1.0, you can install just that file with the following command:', '2020-02-20', 'koko ', 'IMG_20150217_151441.jpg');
INSERT INTO `news` VALUES ('8', 'Title 6', 'The jQuery Bower package contains additional files besides the default distribution. In most cases you can ignore these files, however if you wish to download the default release on it\'s own you can use Bower to install jQuery from one of the above urls instead of the registered package. For example, if you wish to install just the compressed jQuery 2.1.0, you can install just that file with the following command:', '2020-02-20', 'Hovo', 'sirt11.jpg');
INSERT INTO `news` VALUES ('9', 'Title 7', 'The jQuery Bower package contains additional files besides the default distribution. In most cases you can ignore these files, however if you wish to download the default release on it\'s own you can use Bower to install jQuery from one of the above urls instead of the registered package. For example, if you wish to install just the compressed jQuery 2.1.0, you can install just that file with the following command:', '2021-00-05', 'Karen', 'shaggy-hairstyles-for-men.jpg');
INSERT INTO `news` VALUES ('10', 'Title 8', 'CodeIgniter comes with three helper functions that let you fetch POST, COOKIE or SERVER items. The main advantage of using the provided functions rather than fetching an item directly ($_POST[\'something\']) is that the functions will check to see if the item is set and return false (boolean) if not. This lets you conveniently use data without having to test whether an item exists first. In other words, normally you might do something like this:', '2023-02-20', 'SoftCode.Studio', 'Tulips.jpg');
INSERT INTO `news` VALUES ('25', 'Volkswagen Golf 9', 'CodeIgniter comes with three helper functions that let you fetch POST, COOKIE or SERVER items. The main advantage of using the provided functions rather than fetching an item directly ($_POST[\'something\']) is that the functions will check to see if the item is set and return false (boolean) if not. This lets you conveniently use data without having to test whether an item exists first. In other words, normally you might do something like this:', '2015-02-17', 'koko8888', 'IMG_20150217_151609.jpg');
INSERT INTO `news` VALUES ('30', 'Previous 10', 'CodeIgniter comes with three helper functions that let you fetch POST, COOKIE or SERVER items. The main advantage of using the provided functions rather than fetching an item directly ($_POST[\'something\']) is that the functions will check to see if the item is set and return false (boolean) if not. This lets you conveniently use data without having to test whether an item exists first. In other words, normally you might do something like this:', '2020-02-20', 'res', 'yeva.jpg');
INSERT INTO `news` VALUES ('33', 'Resalt 11', 'CodeIgniter comes with three helper functions that let you fetch POST, COOKIE or SERVER items. The main advantage of using the provided functions rather than fetching an item directly ($_POST[\'something\']) is that the functions will check to see if the item is set and return false (boolean) if not. This lets you conveniently use data without having to test whether an item exists first. In other words, normally you might do something like this:', '2011-11-11', 'Suro', 'nissan_micra_1.jpg');
INSERT INTO `news` VALUES ('63', 'Nissan 12', 'CodeIgniter comes with three helper functions that let you fetch POST, COOKIE or SERVER items. The main advantage of using the provided functions rather than fetching an item directly ($_POST[\'something\']) is that the functions will check to see if the item is set and return false (boolean) if not. This lets you conveniently use data without having to test whether an item exists first. In other words, normally you might do something like this:', '2020-02-20', 'Narek', 'images.jpg');
INSERT INTO `news` VALUES ('98', 'Toyota 13', 'I made some changes to the SBDC site directly on the staging server, so I added a SQL dump to the repo for you so that you can work from the latest version.\r\n\r\nSince that SQL dump comes from the staging server, when you import it you will need to make some changes to the domain table. I recommend, actually, that you just make a backup of your existing domain table (call it domain_bak, for example) then delete the new domain table and replace it with your backup.\r\n', '2020-02-20', 'Sirush', 'toyota.jpg');
INSERT INTO `news` VALUES ('99', 'Golf 3', 'I made some changes to the SBDC site directly on the staging server, so I added a SQL dump to the repo for you so that you can work from the latest version.\r\n\r\nSince that SQL dump comes from the staging server, when you import it you will need to make some changes to the domain table. I recommend, actually, that you just make a backup of your existing domain table (call it domain_bak, for example) then delete the new domain table and replace it with your backup.\r\n', '2023-02-20', 'Gavr', 'IMG_20150217_151629.jpg');
INSERT INTO `news` VALUES ('100', 'Title 15', 'I made some changes to the SBDC site directly on the staging server, so I added a SQL dump to the repo for you so that you can work from the latest version.\r\n\r\nSince that SQL dump comes from the staging server, when you import it you will need to make some changes to the domain table. I recommend, actually, that you just make a backup of your existing domain table (call it domain_bak, for example) then delete the new domain table and replace it with your backup.\r\n', '0000-00-00', 'koko', 'IMG_20150217_151423.jpg');
